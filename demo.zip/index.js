/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./dynamoDB.js":
/*!*********************!*\
  !*** ./dynamoDB.js ***!
  \*********************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
eval("\nconst util = __webpack_require__(/*! util */ \"util\");\n\nconst saveMapping = async (cfg, data) => {\n    try {\n        let params = {\n            TableName: cfg.entityTable,\n            Item: data\n        };\n        return cfg.ddbClient.put(params).promise();\n    } catch (error) {\n        console.error(`Failed to save mapping in db:\\n`, util.inspect(error));\n        return;\n    }\n};\n\nconst getMapping = async (cfg, order) => {\n    try {\n        let params = {\n            TableName: cfg.entityTable,\n            ExpressionAttributeNames: {\n                '#order': 'order'\n            },\n            ExpressionAttributeValues: {\n                ':order': order\n            },\n            KeyConditionExpression: '#order = :order'\n        };\n\n        let response = await cfg.ddbClient.query(params).promise();\n        console.log(\"DB response: \", response)\n        if (response.Items && response.Items.length) {\n            return response.Items[0];\n        } else {\n            return false;\n        }\n    } catch (error) {\n        console.error(\n            `Failed to get mapping from db:\\n`,\n            util.inspect(error)\n        );\n        return;\n    }\n};\n\nmodule.exports = { saveMapping, getMapping };\n\n\n//# sourceURL=webpack://mas/./dynamoDB.js?");

/***/ }),

/***/ "./index.js":
/*!******************!*\
  !*** ./index.js ***!
  \******************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("const aws = __webpack_require__(/*! aws-sdk */ \"aws-sdk\");\nconst db = __webpack_require__(/*! ./dynamoDB */ \"./dynamoDB.js\");\nconst lambda = new aws.Lambda({\n    region: 'ap-south-1' //change to your region\n});\nlet cfg;\n\nexports.handler = async (event, context) => {\n    cfg = cfg || (await loadConfiguration());\n    if (!cfg) {\n        return {\n            statusCode: 500,\n            body: JSON.stringify({ error: 'Failed to load configurations' })\n        };\n    }\n\n    const params = {\n        FunctionName: 'crm-marketplaceOrderSync',\n        InvocationType: 'Event',\n        Payload: JSON.stringify({ key: 'value1' })\n    };\n\n    await db.saveMapping(cfg, {order: \"order123\", ...params});\n    await db.getMapping(cfg, \"order123\");\n    try {\n        // Invoke the Lambda function asynchronously\n        await lambda.invoke(params).promise();\n\n        // Return a success response without waiting for the target Lambda to finish\n        return {\n            statusCode: 200,\n            body: JSON.stringify({ message: 'Lambda invoked successfully' })\n        };\n    } catch (error) {\n        console.error('Error invoking Lambda:', error);\n\n        return {\n            statusCode: 500,\n            body: JSON.stringify({ error: 'Failed to invoke Lambda' })\n        };\n    }\n};\n\nasync function loadConfiguration() {\n    try {\n        return {\n            entityTable: 'order',\n            ddbClient: new aws.DynamoDB.DocumentClient()\n        };\n    } catch (error) {\n        console.error('error in loading configuration===>', error.message);\n        return false;\n    }\n}\n\n\n//# sourceURL=webpack://mas/./index.js?");

/***/ }),

/***/ "aws-sdk":
/*!**************************!*\
  !*** external "aws-sdk" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("aws-sdk");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./index.js");
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;